package ar.edu.unlp.info.bbdd2.config;

import ar.edu.unlp.info.bbdd2.repositories.EmpleadoRepository;
import ar.edu.unlp.info.bbdd2.services.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public EmpleadoService createService(){
        EmpleadoRepository repository = this.createRepository();
        return new EmpleadoServiceImpl(repository);
    }

    @Bean
    public EmpleadoRepository createRepository(){
        return new EmpleadoRepository();
    }
}
