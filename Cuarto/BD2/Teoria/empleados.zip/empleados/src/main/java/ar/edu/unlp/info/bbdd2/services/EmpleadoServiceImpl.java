package ar.edu.unlp.info.bbdd2.services;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import ar.edu.unlp.info.bbdd2.model.*;
import ar.edu.unlp.info.bbdd2.repositories.EmpleadoException;
import ar.edu.unlp.info.bbdd2.repositories.EmpleadoRepository;
import org.springframework.transaction.annotation.Transactional;

public class EmpleadoServiceImpl implements EmpleadoService{

    private EmpleadoRepository repository;

    public EmpleadoServiceImpl(EmpleadoRepository repository){
        this.repository=repository;
    }

    @Transactional
    public Empleado createEmpleado(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario) throws EmpleadoException {
        Empleado empleado = new Empleado(legajo,apellido,nombres,genero,telefono,fechaNacimiento,horario);
        Serializable s = this.repository.save(empleado);
        return this.repository.getEmpleadoById((Long)s);
    }

    @Override
    public Optional<Empleado> getEmpleadoByLegajo(String legajo) {
        return this.repository.getEmpleadotByLegajo(legajo);
    }

    @Transactional
    public HorarioLaboral createHorarioLaboral(String descripcion, int horaEntrada, int horaSalida, Set<String> dias) throws EmpleadoException {
        HorarioLaboral h = new HorarioLaboral(descripcion,horaEntrada,horaSalida,dias);
        Serializable s = this.repository.save(h);
        return this.repository.getHorarioById((Integer)s);
    }

    @Transactional
    public EmpleadoAdministrativo createEmpleadoAdministrativo(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, String sector, boolean esProfesional) throws EmpleadoException {
        Empleado empleado = new EmpleadoAdministrativo(legajo,apellido,nombres,genero,telefono,fechaNacimiento,horario,sector,esProfesional);
        Serializable s = this.repository.save(empleado);
        return (EmpleadoAdministrativo) this.repository.getEmpleadoById((Long)s);
    }

    @Transactional
    public EmpleadoVendedor createEmpleadoVendedor(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, boolean esExclusivo) throws EmpleadoException {
        Empleado empleado = new EmpleadoVendedor(legajo,apellido,nombres,genero,telefono,fechaNacimiento,horario,esExclusivo);
        Serializable s = this.repository.save(empleado);
        return (EmpleadoVendedor) this.repository.getEmpleadoById((Long)s);
    }

    @Transactional
    public EmpleadoOperario createEmpleadoOperario(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, String sector) throws EmpleadoException {
        Empleado empleado = new EmpleadoOperario(legajo,apellido,nombres,genero,telefono,fechaNacimiento,horario,sector);
        Serializable s = this.repository.save(empleado);
        return (EmpleadoOperario) this.repository.getEmpleadoById((Long)s);
    }

    @Override
    public List<EmpleadoAdministrativo> getEmpleadosAdministrativos() {
        return this.repository.getEmpleadosAdministrativo();
    }

    @Override
    public List getAllEmpleados() {
        return this.repository.getAllEmpleados();
    }

    @Override
    public List getEmpleadosTurnoM() {
        return this.repository.getEmpleadosTurnoM();
    }

}
