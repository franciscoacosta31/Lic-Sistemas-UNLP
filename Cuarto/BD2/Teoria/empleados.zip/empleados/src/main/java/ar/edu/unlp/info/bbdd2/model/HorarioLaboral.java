package ar.edu.unlp.info.bbdd2.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
public class HorarioLaboral {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id_horario")
    private Integer id;
    private String descripcion;
    private Integer horaEntrada;
    private Integer horaSalida;
    @ElementCollection
    @CollectionTable(name = "horario_dias_semana", joinColumns = @JoinColumn(name = "id_horario"))
    @Column(name = "dia_semana")
    private Set<String> diasDeLaSemana= new HashSet<String>();

    public HorarioLaboral() {
        diasDeLaSemana = new HashSet<String>();
    }

    public HorarioLaboral(String descripcion, Integer horaEntrada, Integer horaSalida, Set<String> diasDeLaSemana) {
        this.descripcion = descripcion;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.diasDeLaSemana=diasDeLaSemana;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(Integer horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public Integer getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(Integer horaSalida) {
        this.horaSalida = horaSalida;
    }

    public Set<String> getDiasDeLaSemana() {
        return diasDeLaSemana;
    }

    public void setDiasDeLaSemana(Set<String> diasDeLaSemana) {
        this.diasDeLaSemana = diasDeLaSemana;
    }

    public void agregarDiaDeLaSemana(String dia){
        this.diasDeLaSemana.add(dia);
    }

    public void eliminarDiaDeLaSemana(String dia){
        this.diasDeLaSemana.remove(dia);
    }
}
