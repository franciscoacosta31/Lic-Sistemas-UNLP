package ar.edu.unlp.info.bbdd2.repositories;

import ar.edu.unlp.info.bbdd2.model.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class EmpleadoRepository {

    @Autowired
    private SessionFactory sessionFactory;

    public Serializable save(Object object) throws EmpleadoException {
        Session session = null;
        try {
            session = this.sessionFactory.getCurrentSession();
            return session.save(object);
        } catch (Exception e){
            if (e.getClass().equals(org.hibernate.exception.ConstraintViolationException.class)) {
                throw new EmpleadoException("Constraint Violation");}
            else {System.out.println(e.toString());
                throw new EmpleadoException("Object can't be save");}
        }
    }

    public void update(Object object) {
        Session session = null;
        try {
            session = this.sessionFactory.getCurrentSession();
            session.update(object);
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }


    public Optional<Empleado> getEmpleadotByLegajo(String legajo) {
        return this.sessionFactory.getCurrentSession().createQuery("from Empleado where legajo = :legajo ").setParameter("legajo", legajo).uniqueResultOptional();
    }

    public Empleado getEmpleadoById(Long s) {
        return (Empleado)this.sessionFactory.getCurrentSession().createQuery("from Empleado where id = :id ").setParameter("id", s).uniqueResult();
    }

    public HorarioLaboral getHorarioById(Integer s) {
        return (HorarioLaboral) this.sessionFactory.getCurrentSession().createQuery("from HorarioLaboral where id = :id").setParameter("id",s).uniqueResult();
    }

    public List<EmpleadoAdministrativo> getEmpleadosAdministrativo() {
        return (List<EmpleadoAdministrativo>) this.sessionFactory.getCurrentSession().createQuery("from EmpleadoAdministrativo").list();
    }

    public List getAllEmpleados() {
        return this.sessionFactory.getCurrentSession().createQuery("from Empleado").list();
    }

    public List getEmpleadosTurnoM() {
        return this.sessionFactory.getCurrentSession().createQuery("from Empleado e join e.horario h where h.descripcion like :desc").setParameter("desc","%mañana%").list();
    }
}
