package ar.edu.unlp.info.bbdd2.services;

import ar.edu.unlp.info.bbdd2.model.*;
import ar.edu.unlp.info.bbdd2.repositories.EmpleadoException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface EmpleadoService {

    Empleado createEmpleado(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario) throws EmpleadoException;
    Optional<Empleado> getEmpleadoByLegajo(String legajo);
    HorarioLaboral createHorarioLaboral(String descripcion, int horaEntrada, int horaSalida, Set<String> dias) throws EmpleadoException;
    EmpleadoAdministrativo createEmpleadoAdministrativo(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, String sector, boolean esProfesional) throws EmpleadoException;
    EmpleadoVendedor createEmpleadoVendedor(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, boolean esExclusivo) throws EmpleadoException;
    EmpleadoOperario createEmpleadoOperario(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, String sector) throws EmpleadoException;

    List<EmpleadoAdministrativo> getEmpleadosAdministrativos();

    List getAllEmpleados();

    List getEmpleadosTurnoM();
}

