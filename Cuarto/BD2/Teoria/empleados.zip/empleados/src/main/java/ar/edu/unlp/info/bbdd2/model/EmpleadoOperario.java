package ar.edu.unlp.info.bbdd2.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import java.util.Date;

@Entity
@DiscriminatorValue("OPERARIO")
//JOINED
//@Table(name = "empleados_operarios")
//@PrimaryKeyJoinColumn(name = "id_empleado")
//TABLE_PER_CLASS
//@Table(name = "empleados_operarios")
public class EmpleadoOperario extends Empleado{

    private String sector;

    public EmpleadoOperario() {
    }

    public EmpleadoOperario(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento,HorarioLaboral horario, String sector) {
        super(legajo, apellido, nombres, genero, telefono, fechaNacimiento,horario);
        this.sector = sector;
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }
}
