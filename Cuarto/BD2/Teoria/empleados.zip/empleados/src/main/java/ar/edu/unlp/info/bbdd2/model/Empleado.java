package ar.edu.unlp.info.bbdd2.model;

import javax.persistence.*;

import java.util.Date;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
//SINGLE_TABLE
@Table(name = "empleados")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_empleado", discriminatorType = DiscriminatorType.STRING)
// JOINED
//@Table(name = "empleados")
//@Inheritance(strategy = InheritanceType.JOINED)
//TABLE_PER_CLASS
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Empleado {
    @Id
    @Column(name = "id_empleado")
    //@GeneratedValue(strategy = IDENTITY)
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected Long id;
    @Column(nullable = false)
    protected String legajo;
    @Column(nullable = false)
    protected String apellido;
    @Column(nullable = false)
    protected String nombres;
    @Column(nullable = false)
    protected String genero;
    @Column(nullable = false)
    protected String telefono;
    @Column(nullable = false)
    protected Date fechaNacimiento;
    @ManyToOne
    @JoinColumn(name = "horario_id")
    protected HorarioLaboral horario;

    public Empleado(){
    }

    public Empleado(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento,HorarioLaboral horario){
        super();
        this.legajo=legajo;
        this.apellido=apellido;
        this.nombres=nombres;
        this.genero=genero;
        this.telefono=telefono;
        this.fechaNacimiento=fechaNacimiento;
        this.horario=horario;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLegajo() {
        return legajo;
    }

    public void setLegajo(String legajo) {
        this.legajo = legajo;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public HorarioLaboral getHorario() {
        return horario;
    }

    public void setHorario(HorarioLaboral horario) {
        this.horario = horario;
    }
}

