package ar.edu.unlp.info.bbdd2.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import java.util.Date;

@Entity
@DiscriminatorValue("ADMIN")
//JOINED
//@Table(name = "empleados_administrativos")
//@PrimaryKeyJoinColumn(name = "id_empleado")
//TABLE_PER_CLASS
//@Table(name = "empleados_administrativos")
public class EmpleadoAdministrativo extends Empleado {
    private String Sector;
    private boolean esProfesional;

    public EmpleadoAdministrativo() {
    }

    public EmpleadoAdministrativo(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, String sector, boolean esProfesional) {
        super(legajo, apellido, nombres, genero, telefono, fechaNacimiento,horario);
        Sector = sector;
        this.esProfesional = esProfesional;
    }

    public String getSector() {
        return Sector;
    }

    public void setSector(String sector) {
        Sector = sector;
    }

    public boolean isEsProfesional() {
        return esProfesional;
    }

    public void setEsProfesional(boolean esProfesional) {
        this.esProfesional = esProfesional;
    }



}
