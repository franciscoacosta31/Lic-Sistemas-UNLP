package ar.edu.unlp.info.bbdd2.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import java.util.Date;

@Entity
@DiscriminatorValue("VENDEDOR")
//JOINED
//@PrimaryKeyJoinColumn(name = "id_empleado")
//@Table(name = "empleados_vendedores")
//TABLE_PER_CLASS
//@Table(name = "empleados_vendedores")
public class EmpleadoVendedor extends Empleado {

    private boolean esExclusivo;

    public EmpleadoVendedor() {
    }

    public EmpleadoVendedor(String legajo, String apellido, String nombres, String genero, String telefono, Date fechaNacimiento, HorarioLaboral horario, boolean esExclusivo) {
        super(legajo, apellido, nombres, genero, telefono, fechaNacimiento,horario);
        this.esExclusivo = esExclusivo;
    }

    public boolean isEsExclusivo() {
        return esExclusivo;
    }

    public void setEsExclusivo(boolean esExclusivo) {
        this.esExclusivo = esExclusivo;
    }
}
