package ar.edu.unlp.info.bbdd2.repositories;

public class EmpleadoException extends Exception{

    public EmpleadoException(String message){
        super(message);
    }

}
