package ar.edu.unlp.info.bbdd2.util;

import ar.edu.unlp.info.bbdd2.model.*;
import ar.edu.unlp.info.bbdd2.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.text.SimpleDateFormat;

import java.text.SimpleDateFormat;
import java.util.*;

public class DBInitializer {

    @Autowired
    EmpleadoService service;

    public void prepareDB() throws Exception {

        Set<String> dias = new HashSet<String>();
        dias.add("lunes"); dias.add("martes");dias.add("miercoles"); dias.add("jueves");dias.add("viernes");
        HorarioLaboral luvi812 = this.service.createHorarioLaboral("lu-vi-mañana",8,12,dias);
        HorarioLaboral luvi1418 = this.service.createHorarioLaboral("lu-vi-tarde",14,18,dias);
        dias = new HashSet<String>();
        dias.add("sabado");
        HorarioLaboral sabado = this.service.createHorarioLaboral("sabado",8,13,dias);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        Random rand = new Random();
        //Empleado emp001 = service.createEmpleado("Emp001","Lopez","Juan Pablo","Masculino","1234567890",sdf.parse("1982-01-01"));
        // Listas de nombres y apellidos comunes en español
        String[] nombresMasculinos = {"Juan", "Carlos", "Luis", "Miguel", "José", "Javier", "Francisco", "Pedro", "Diego", "Sergio"};
        String[] nombresFemeninos = {"María", "Carmen", "Ana", "Lucía", "Laura", "Sofía", "Marta", "Isabel", "Patricia", "Elena"};
        String[] apellidos = {"García", "Martínez", "Rodríguez", "López", "Hernández", "González", "Pérez", "Sánchez", "Ramírez", "Torres"};
        // Horarios posibles
        HorarioLaboral[] horarios = {luvi812, luvi1418, sabado};
        //Sectores Administrativo
        String[] sectoresAdministrativo = {"Contable", "RRHH", "Secretaria", "Finanzas", "Sueldos","Maestranza"};
        //Sectores Operarios
        String[] sectoresOperarios = {"Logistica", "Produccion", "Pañol", "Tecnico"};

        for (int i = 1; i <= 1000; i++) {
            // Legajo único
            String legajo = "Emp" + String.format("%03d", i);

            // Alternar género
            boolean masculino = i % 2 == 0;
            String genero = masculino ? "Masculino" : "Femenino";

            // Elegir nombres y apellidos aleatorios
            String nombres = masculino ? nombresMasculinos[rand.nextInt(nombresMasculinos.length)]
                    : nombresFemeninos[rand.nextInt(nombresFemeninos.length)];
            String apellido = apellidos[rand.nextInt(apellidos.length)];

            // Teléfono único (simulado)
            String telefono = "11" + String.format("%08d", i);

            // Fecha de nacimiento aleatoria entre 1980 y 2005
            int year = 1980 + rand.nextInt(26); // 1980-2005
            int month = rand.nextInt(12);       // 0-11
            int day = 1 + rand.nextInt(28);     // 1-28
            cal.set(year, month, day);
            Date fechaNacimiento = cal.getTime();
            // Elegir entidad HorarioLaboral
            HorarioLaboral horario = horarios[rand.nextInt(horarios.length)];

            // 🔥 Distribución por tipo
            if (i <= 50) {
                // 50 Administrativos
                String sector = sectoresAdministrativo[rand.nextInt(sectoresAdministrativo.length)];
                boolean esProfesional = rand.nextBoolean();

                service.createEmpleadoAdministrativo(
                        legajo, apellido, nombres, genero, telefono, fechaNacimiento,
                        horario, sector, esProfesional
                );

            } else if (i <= 200) {
                // 150 Vendedores (51–200)
                boolean esExclusivo = rand.nextBoolean();

                service.createEmpleadoVendedor(
                        legajo, apellido, nombres, genero, telefono, fechaNacimiento,
                        horario, esExclusivo
                );

            } else {
                // 800 Operarios (201–1000)
                String sector = sectoresOperarios[rand.nextInt(sectoresOperarios.length)];

                service.createEmpleadoOperario(
                        legajo, apellido, nombres, genero, telefono, fechaNacimiento,
                        horario, sector
                );
            }


            // Crear empleado usando tu servicio
            //service.createEmpleado(legajo, apellido, nombres, genero, telefono, fechaNacimiento,horario);
        }
    }
}