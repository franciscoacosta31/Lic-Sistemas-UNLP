package ar.edu.unlp.info.bbdd2.services;

import ar.edu.unlp.info.bbdd2.config.HibernateConfiguration;
import ar.edu.unlp.info.bbdd2.model.Empleado;
import ar.edu.unlp.info.bbdd2.model.HorarioLaboral;
import org.apache.commons.dbcp2.BasicDataSource;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringJUnitConfig(HibernateConfiguration.class)
@Transactional
public class EmpleadoRepositoryTest {

        @Autowired
        private SessionFactory sessionFactory;

        /*@Test
        void testGuardarEmpleado() {
            Session session = sessionFactory.getCurrentSession();
            Empleado e = new Empleado("123", "Perez", "Juan", "M", "12345678", new Date());
            session.persist(e);
            assertNotNull(e.getId()); // Hibernate asigna ID al persistir
        }*/

        @Test
        void testGuardarHorario() {
            Session session = sessionFactory.getCurrentSession();
            //Empleado e = new Empleado("123", "Perez", "Juan", "M", "12345678", new Date());
            Set<String> dias = new HashSet<String>();
            dias.add("lunes"); dias.add("martes");dias.add("miercoles"); dias.add("jueves");dias.add("viernes");
            HorarioLaboral h = new HorarioLaboral("lu-vi-mañana",8,12,dias);
            session.persist(h);
            assertNotNull(h.getId()); // Hibernate asigna ID al persistir
        }
}