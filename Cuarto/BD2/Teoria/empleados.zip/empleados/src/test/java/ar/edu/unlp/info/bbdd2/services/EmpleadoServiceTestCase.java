package ar.edu.unlp.info.bbdd2.services;

import ar.edu.unlp.info.bbdd2.config.*;
import ar.edu.unlp.info.bbdd2.model.*;
import ar.edu.unlp.info.bbdd2.repositories.EmpleadoException;
import ar.edu.unlp.info.bbdd2.util.DBInitializer;

import org.hibernate.Session;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;

import java.util.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AppConfig.class, HibernateConfiguration.class, DBInitializerConfig.class}, loader = AnnotationConfigContextLoader.class)
@Transactional
@Rollback(false)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class EmpleadoServiceTestCase {

    @Autowired
    DBInitializer initializer;

    @Autowired
    EmpleadoService service;


    @BeforeAll
    public void prepareDB() throws Exception {
        this.initializer.prepareDB();
    }


    /*@Test
    public void testCreateEmpleado() throws EmpleadoException{
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 1982);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        Date dob = cal.getTime();
        Empleado e1 = this.service.createEmpleado("E002","Lopez","Juan","Masculino","1234567890",dob);
        assertNotNull(e1.getId());
        assertEquals("Juan",e1.getNombres());
        Optional<Empleado> e2 = this.service.getEmpleadoByLegajo("E002");
        if (! e2.isPresent()) {
            throw new EmpleadoException("Empleado not found");
        }
        Empleado emp = e2.get();
        assertNotNull(emp.getId());
        assertEquals("Lopez",emp.getApellido());
    }*/

    /*@Test
    void testGuardarHorario() throws EmpleadoException{
        Set<String> dias = new HashSet<String>();
        dias.add("lunes"); dias.add("martes");dias.add("miercoles"); dias.add("jueves");dias.add("viernes");
        //HorarioLaboral h = new HorarioLaboral("lu-vi-mañana",8,12,dias);
        HorarioLaboral h = this.service.createHorarioLaboral("lu-vi-mañana",8,12,dias);
        assertNotNull(h.getId()); // Hibernate asigna ID al persistir
    }*/

    /*@Test
    void testGetEmpleadosAdministrativos() {
        long inicio = System.nanoTime();
        List administrativos = this.service.getEmpleadosAdministrativos();
        assertNotEquals(0, administrativos.size());
        long fin = System.nanoTime();
        System.out.println("Tiempo de ejecución: " + ((fin - inicio) / 1_000_000) + " ms");
    }*/

    /*@Test
    void testGetAllEmpleados(){
        long inicio = System.nanoTime();
        List empleados = this.service.getAllEmpleados();
        assertNotEquals(0, empleados.size());
        long fin = System.nanoTime();
        System.out.println("Tiempo de ejecución: " + ((fin - inicio) / 1_000_000) + " ms");
    }*/

    @Test
    void testGetEmpleadosTurnoM() {
        long inicio = System.nanoTime();
        List empleados = this.service.getEmpleadosTurnoM();
        assertNotEquals(0, empleados.size());
        long fin = System.nanoTime();
        System.out.println("Tiempo de ejecución: " + ((fin - inicio) / 1_000_000) + " ms");
    }
}
